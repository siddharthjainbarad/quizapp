package com.siddharth.quizapp.model;

public class Question {

}
